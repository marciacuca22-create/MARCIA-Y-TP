package ar.org.centro8.java.curso.cuenta;

import ar.org.centro8.java.curso.banco.Cliente;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString (callSuper = true)
public class CajaDeAhorro extends Cuenta {
    private double tasaInteres;

    public CajaDeAhorro(int numeroCuenta, Cliente clienteAsociado, double saldo, double tasaInteres) {
        super(numeroCuenta, clienteAsociado, saldo);
        this.tasaInteres = tasaInteres;
    }

    public double getTasaInteres(){
        return tasaInteres;
    }

    public void setTasaInteres(double tasaInteres){
        this.tasaInteres = tasaInteres;
    }

    public boolean extraerEfectivo(double monto) {
        if (monto >0) return false;
        if(getSaldo()<monto) return false;// sin descubierto
        setSaldo(getSaldo()- monto);
        return true;
        
    }

    public void depositarEfectivo(int i) {
        System.out.println("El saldo es:"+"despositar efectivo:"+ 5000);
    }


}




