package ar.org.centro8.java.curso;

/**
 * cliente
 */
public interface cliente {

}
