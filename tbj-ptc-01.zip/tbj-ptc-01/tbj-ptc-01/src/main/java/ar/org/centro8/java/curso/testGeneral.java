package ar.org.centro8.java.curso;

import ar.org.centro8.java.curso.banco.Cliente;
import ar.org.centro8.java.curso.cuenta.CajaDeAhorro;
import ar.org.centro8.java.curso.cuenta.CuentaConvertibilidad;
import ar.org.centro8.java.curso.cuenta.CuentaCorriente;

public class testGeneral{
	public static void main(String[] args) {
		Cliente cliente = new Cliente(1){};
		System.out.println("tes de caja de ahoarro");
		CajaDeAhorro ca = new CajaDeAhorro(1001, cliente, 1000, 0.5);
		System.out.println("Inicial:"+ ca.getSaldo());
		ca.depositarEfectivo(2000);
		System.out.println("Depositar 2000 ->" + ca.getSaldo()+"(esperando 12000");
		ca.extraerEfectivo(3000);
		System.out.println("Extraer 3000 ->" + ca.getSaldo()+"(esperando 9000)");
		boolean noPudo = ca.extraerEfectivo(20000);
		System.out.println("Intenta extraer 20000 -> pudo?"+ noPudo +"salso:"+ ca.getSaldo() +"(debe fallar)");
		System.out.println(ca.toString());
		System.out.println("");

		System.out.println("===test de cuenta corriente");
		CuentaCorriente cc = new CuentaCorriente(1002,cliente,10000,5000);
		System.out.println("Inicial:"+ cc.getSaldo() +"Descubierto:"+ cc.getMontoAutorizado());
		cc.extraerEfectivo(12000);
		System.out.println("extraer 12000(usa descubierto)-> saldo:"+ cc.getSaldo()+ "(esperando - 2000)");
		cc.despositarEfectivo(5000);
		System.out.println("Depositar 5000 -> saldo:"+ cc.getSaldo()+"(esperando 3000)");
		System.out.println("");

		System.out.println("=== cuenta de convertibidad===");
		CuentaConvertibilidad cv = new CuentaConvertibilidad(1003, cliente, 10000,5000,100,1200);
		System.out.println("Inicial Pesos:"+ cv.getSaldo()+ "Dolares:" + cv.getSaldoDolares() +"cotizacion:"+ cv.getCotizacion());
		
		cv.depositarDolares(50);
		System.out.println("Extraer U$D 50 ->Dolares:"+ cv.getSaldoDolares()+ "(esperando 150)");

		cv.extraerDolares(30);
		System.out.println("Extraer U$D 30 -> Dolares:"+ cv.getSaldoDolares()+ "(esperando 120)");

		cv.convertirPesosADolares(2400);
		System.out.println("Convierte $2400 a dolares -> pesos"+ cv.getSaldo()+ "Dolares:"+ cv.getSaldoDolares()+"(pesos 7600, dolares 122)");
		
		cv.convertirPesosADolares(2);
		System.out.println("Covertir U$D 2 a pesos -> pesos:"+ cv.getSaldo()+ "Dolares:"+ cv.getSaldoDolares()+"(pesos 1000,dolares 120)");

		cv.extraerEfectivo(12000);
		System.out.println("Extraer $ 12000 con descubierto -> saldo pesos:"+ cv.getSaldo());
	}
}
