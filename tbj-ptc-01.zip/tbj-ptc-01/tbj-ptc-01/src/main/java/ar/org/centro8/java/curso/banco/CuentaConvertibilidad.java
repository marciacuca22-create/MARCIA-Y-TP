package ar.org.centro8.java.curso.banco;

import java.util.zip.ZipEntry;

import ar.org.centro8.java.curso.cuenta.cuentaCorriente;
import lombok.Getter;
import lombok.Setter;

@Getter
public class CuentaConvertibilidad extends cuentaCorriente{
    private double saldoDolares;

    public CuentaConvertibilidad(double saldoDolares, String nombreFantasia, Object object, int i, int j) {
        super(0, null, saldoDolares, saldoDolares);
        this.saldoDolares = saldoDolares;
    }


    //Depositar dolares
    public void depositarDolares(double monto){
        this.saldoDolares += monto;
            
    }

    //extraer dolares(si descubierto)
    public void extraerDolares(double monto) {
        if(monto > 0 && monto <= saldoDolares){
        this.saldoDolares-= monto;
    
    }
}
//convertir peso a dolares
public void convertirPesosADolares(double montoPesos, double cotizacionDorar){
    //tasaConversion = cuantos peso vale 1 dolar.ej 1000
    if (montoPesos > 0 && montoPesos <= getSaldoDolares()){
        double dolares=montoPesos/ cotizacionDorar;
        extraerEfectivo(montoPesos);//usa el metodo pesos
        this.saldoDolares += dolares;
    }
}


//convertir dolares a pesos
public void convertirDolaresAPesos(double montoDolares,double cotizacionDolar){
    if (montoDolares >0 && montoDolares <= saldoDolares) {
        double pesos = montoDolares/cotizacionDolar;
        this.saldoDolares -= montoDolares;
        depositarDolares(pesos);
    }
}

public void ClienteAsociado(double montoDolares){
    if(montoDolares <= montoDolares);
    double saldo =- montoDolares;
    System.out.println(" el monto es negativo o exedo el saldo disponible");

    }


}

