package ar.org.centro8.java.curso.banco;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@AllArgsConstructor
public abstract class Cliente{
    private  int numeroCliente;

}



    
